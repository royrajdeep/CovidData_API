﻿using CovidData_API.Contracts;
using CovidData_API.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace CovidData_API.Controllers
{
    /// <summary>
    /// </summary>
    [Produces("application/json")]
    [Route("api/GetGrowthRate")]
    public class GetGrowthRateController : Controller
    {

        private readonly IGetGrowthRateRepository _getGrowthRateRepository;
        /// <summary>
        /// Constructor that creates an instance of the API interface.
        /// </summary>
        public GetGrowthRateController(IGetGrowthRateRepository GetGrowthRateRepository)
        {
            _getGrowthRateRepository = GetGrowthRateRepository;
        }

        /// <summary>
        /// Gets a report on the number of cases in a location and the growth percent. Input Params - County, State, DateRange. 
        /// Example - Baldwin, Alabama, 5/1/2020-5/2/2020
        /// Note: A City name may be provided for the param "County". Application will lookup the appropriate county name.
        /// </summary>
        /// <param name="County"></param>
        /// /// <param name="State"></param>
        /// <param name="DateRange"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(GrowthReportResponse), 200)]
        public IActionResult GetGrowthRate(string County, string State, string DateRange)
        {
            return Ok(_getGrowthRateRepository.GetGrowthRate(County, State, DateRange));
        }
    }
}