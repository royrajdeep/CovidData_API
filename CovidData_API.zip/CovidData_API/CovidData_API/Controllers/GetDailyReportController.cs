﻿using CovidData_API.Contracts;
using CovidData_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace CovidData_API.Controllers
{
    /// <summary>
    /// </summary>
    [Produces("application/json")]
    [Route("api/GetDailyReport")]
    public class GetDailyReportController : Controller
    {

        private readonly IGetDailyReportRepository _getDailyReportRepository;
        /// <summary>
        /// Constructor that creates an instance of the API interface.
        /// </summary>
        public GetDailyReportController(IGetDailyReportRepository GetDailyReportRepository)
        {
            _getDailyReportRepository = GetDailyReportRepository;
        }

        /// <summary>
        /// Gets a Daily report on total number of cases per day along with the increase/decrease number per day.
        /// Input Params - County, State, DateRange. Example - Baldwin, Alabama, 5/1/2020-5/2/2020
        /// Note: A City name may be provided for the param "County". Application will lookup the appropriate county name.
        /// </summary>
        /// <param name="County"></param>
        /// /// <param name="State"></param>
        /// <param name="DateRange"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(DailyReportResponse), 200)]
        public IActionResult GetDailyReport(string County, string State, string DateRange)
        {
            return Ok(_getDailyReportRepository.GetDailyReport(County, State, DateRange));
        }
    }
}