﻿using CovidData_API.Models;

namespace CovidData_API.Contracts
{
    /// <summary>
    /// Get Covid Daily Report
    /// </summary>
    /// <remarks>
    /// Your project will have a class that inherits from this interface in the Repositories directory, so you need to make sure both are in sync.
    /// </remarks>
    public interface IGetDailyReportRepository
    {
        /// <summary>
        /// Gets Covid Daily Report
        /// </summary>
        /// <returns>
        /// All Covid Data
        /// </returns>
        DailyReportResponse GetDailyReport(string County = "", string State = "", string DateRange = "");
    }
}
