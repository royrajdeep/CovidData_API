﻿using System.Collections.Generic;

namespace CovidData_API.Models
{
    /// <summary>
    /// Model for expected Daily Report.
    /// </summary>
    public class DailyReportResponse
    {
        public string County { get; set; } = string.Empty;
        public string State { get; set; } = string.Empty;
        public List<DailyBreakdownData> BreakdownData { get; set; } = new List<DailyBreakdownData>();
        public string Status { get; set; } = string.Empty;
        public string ErrorMsg { get; set; } = string.Empty;
    }

    /// <summary>
    /// DailyBreakdownData
    /// </summary>
    public class DailyBreakdownData
    {
        public string Location { get; set; } = string.Empty;
        public string Date { get; set; } = string.Empty;
        public string TotalCases { get; set; } = string.Empty;
        public string NewCases { get; set; } = string.Empty;
    }
}

