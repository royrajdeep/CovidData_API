﻿namespace CovidData_API.Models
{
    /// <summary>
    /// Model for expected IVResponse.
    /// </summary>
    public class IVResponse
    {
        public string County { get; set; } = string.Empty;
        public string State { get; set; } = string.Empty;
        public string Latitude { get; set; } = string.Empty;
        public string Longitude { get; set; } = string.Empty;
        public string Avg_Daily_Cases { get; set; } = string.Empty;
        public string Min_No_Of_Cases { get; set; } = string.Empty;
        public string Max_No_Of_Cases { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string ErrorMsg { get; set; } = string.Empty;
    }
}

