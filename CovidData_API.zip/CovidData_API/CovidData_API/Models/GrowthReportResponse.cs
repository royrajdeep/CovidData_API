﻿using System.Collections.Generic;

namespace CovidData_API.Models
{
    /// <summary>
    /// GrowthReport Model
    /// </summary>
    public class GrowthReportResponse
    {
        public List<GrowthReportResponseItems> Items { get; set; } = new List<GrowthReportResponseItems>();
        public string Status { get; set; } = string.Empty;
        public string ErrorMsg { get; set; } = string.Empty;
    }

    /// <summary>
    /// GrowthReport items
    /// </summary>
    public class GrowthReportResponseItems
    {
        public string Location { get; set; } = string.Empty;
        public string Number_Cases_At_Start { get; set; } = string.Empty;
        public string Number_Of_New_Cases { get; set; } = string.Empty;
        public string GrowthPercent { get; set; } = string.Empty;
    }
}

