﻿using System.Collections.Generic;

namespace CovidData_API.InternalItems.Models
{
    public class CovidData
    {
        public string UID { get; set; } = string.Empty;
        public string iso2 { get; set; } = string.Empty;
        public string iso3 { get; set; } = string.Empty;
        public string code3 { get; set; } = string.Empty;
        public string FIPS { get; set; } = string.Empty;
        public string Admin2 { get; set; } = string.Empty;
        public string Province_State { get; set; } = string.Empty;
        public string Country_Region { get; set; } = string.Empty;
        public string Lat { get; set; } = string.Empty;
        public string Long { get; set; } = string.Empty;
        public string Combined_Key { get; set; } = string.Empty;
        public List<KeyValuePair<string, string>> DailyData { get; set; }
    }
}
