﻿using CovidData_API.Contracts;
using CovidData_API.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using CovidData_API.InternalItems.Models;
using System.Linq;
using System;
using CovidData_API.Utilities;

namespace CovidData_API.Repositories
{
    /// <summary>
    /// This is the main class 
    /// </summary>
    public class GetCovidDataRepository : IGetCovidDataRepository
    {
        
        private IConfiguration Config { get; set; }

        /// <summary>
        /// This is the constructor for the GetCovidDataRepository.
        /// </summary>
        /// <param name="config">The config (appsettings.json) is being injected at the time of creation.</param>
        public GetCovidDataRepository(IConfiguration config)
        {
            Config = config;
        }

        /// <summary>
        /// Retrieve Covid Data
        /// </summary>
        /// <param name="County"></param>
        /// <param name="State"></param>
        /// <param name="DateRange"></param>
        /// <returns>IVResponse</returns>
        public IVResponse GetCovidData(string County = "", string State = "", string DateRange = "")
        {
            try
            {
                string CovidSourceURL = Utility.GetKeyFromSettings(Config,"CovidSourceURL");
                List<CovidData> AllCovidData = Utility.GetCSV(CovidSourceURL);
                if (!(AllCovidData.Any(i => i.Admin2 == County)) && !String.IsNullOrEmpty(County) && !String.IsNullOrEmpty(State))
                {
                    County = Utility.GetCountyInfo(Config, County, State);
                }
                DateTime StartDate = DateTime.MinValue, EndDate = DateTime.Today;

                if (!String.IsNullOrEmpty(DateRange))
                {
                    string[] Dates = DateRange.Split('-');
                    StartDate = Convert.ToDateTime(Dates[0]);
                    EndDate = Convert.ToDateTime(Dates[1]);
                }

                //Check if the County or State provided as Param are valid. If not then return a friendly (error) message.
                if (!(AllCovidData.Any(i => i.Admin2 == County) || AllCovidData.Any(i => i.Province_State == State)))
                {
                    return JObject.FromObject(new IVResponse
                    {
                        ErrorMsg = "Please enter a valid County/City or State",Status = "FAIL"
                    }).ToObject<IVResponse>();
                }


                IEnumerable<KeyValuePair<string, string>> Query = new List<KeyValuePair<string, string>>();
                string Latitude = String.Empty, Longitude = String.Empty;
                Regex regExState = new Regex(String.IsNullOrEmpty(State) ? "." : State);
                Regex regExCounty = new Regex(String.IsNullOrEmpty(County) ? "." : County);

                Query = from data in AllCovidData
                        where regExState.IsMatch(data.Province_State) && regExCounty.IsMatch(data.Admin2)
                        from data2 in data.DailyData
                        where Convert.ToDateTime(data2.Key) >= StartDate && Convert.ToDateTime(data2.Key) <= EndDate
                        select data2;
                
                if(Query.Count() == 0)
                {
                    return JObject.FromObject(new IVResponse
                    {
                        ErrorMsg = "Please enter a valid County/City or State",Status = "FAIL"
                    }).ToObject<IVResponse>();
                }

                if (!String.IsNullOrEmpty(County))
                {
                    Latitude = AllCovidData.FirstOrDefault(i => i.Admin2 == County).Lat;
                    Longitude = AllCovidData.FirstOrDefault(i => i.Admin2 == County).Long;
                }

                var Avg = Query.Average(i => Convert.ToDouble(i.Value));
                var Min = Query.OrderBy(i => Convert.ToDouble(i.Value)).FirstOrDefault();
                var Max = Query.OrderByDescending(i => Convert.ToDouble(i.Value)).FirstOrDefault();

                return JObject.FromObject(new IVResponse
                {
                    County = County,
                    State = State,
                    Avg_Daily_Cases = String.Format("{0:N2}", Avg),
                    Min_No_Of_Cases = String.Format("{0:N2}", Min.Value) + " (Date - " + Min.Key + ")",
                    Max_No_Of_Cases = String.Format("{0:N2}", Max.Value) + " (Date - " + Max.Key + ")",
                    Latitude = Latitude,
                    Longitude = Longitude,
                    Status = "SUCCESS"
                }).ToObject<IVResponse>();
            }
            catch(Exception ex)
            {
                return JObject.FromObject(new IVResponse
                {
                    Status = "FAIL", ErrorMsg = ex.Message,
                }).ToObject<IVResponse>();
            }
        }
    }
}
