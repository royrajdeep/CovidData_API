﻿using CovidData_API.Contracts;
using CovidData_API.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using CovidData_API.InternalItems.Models;
using System.Linq;
using System;
using CovidData_API.Utilities;
using System.Text.RegularExpressions;

namespace CovidData_API.Repositories
{
    /// <summary>
    /// This is the main class 
    /// </summary>
    public class GetGrowthRateRepository : IGetGrowthRateRepository
    {
        private IConfiguration Config { get; set; }

        /// <summary>
        /// This is the constructor for the GetGrowthRateRepository.
        /// </summary>
        /// <param name="config">The config (appsettings.json) is being injected at the time of creation.</param>
        public GetGrowthRateRepository(IConfiguration config)
        {
            Config = config;
        }

        /// <summary>
        /// Retrieve Covid Data
        /// </summary>
        /// <param name="County"></param>
        /// /// <param name="State"></param>
        /// /// <param name="DateRange"></param>
        /// <returns>IVResponse</returns>
        public GrowthReportResponse GetGrowthRate(string County = "", string State = "", string DateRange = "")
        {
            List<GrowthReportResponseItems> GrRepResponseItems = new List<GrowthReportResponseItems>();
            try
            {
                string CovidSourceURL = Utility.GetKeyFromSettings(Config, "CovidSourceURL");
                List<CovidData> AllCovidData = Utility.GetCSV(CovidSourceURL);
                
                if (!(AllCovidData.Any(i => i.Admin2 == County)) && !String.IsNullOrEmpty(County) && !String.IsNullOrEmpty(State))
                {
                    County = Utility.GetCountyInfo(Config,County, State);
                }
                DateTime StartDate = DateTime.MinValue, EndDate = DateTime.Today;

                if (!String.IsNullOrEmpty(DateRange))
                {
                    string[] Dates = DateRange.Split('-');
                    StartDate = Convert.ToDateTime(Dates[0]);
                    //StartDate = StartDate.AddDays(-1);
                    EndDate = Convert.ToDateTime(Dates[1]);
                }

                //Check if the County or State provided as Param are valid. If not then return a friendly (error) message.
                if (!(AllCovidData.Any(i => i.Admin2 == County) || AllCovidData.Any(i => i.Province_State == State)))
                {
                    return JObject.FromObject(new GrowthReportResponse
                    {
                        ErrorMsg = "Please enter a valid County/City or State",Status = "FAIL"
                    }).ToObject<GrowthReportResponse>();
                }


                List<DailyBreakdownData> DBreakdownData = new List<DailyBreakdownData>();
                Regex regExState = new Regex(String.IsNullOrEmpty(State) ? "." : State);
                Regex regExCounty = new Regex(String.IsNullOrEmpty(County) ? "." : County);

                var Query = from data in AllCovidData
                            where regExState.IsMatch(data.Province_State) && regExCounty.IsMatch(data.Admin2)
                            from data2 in data.DailyData
                            where Convert.ToDateTime(data2.Key) >= StartDate && Convert.ToDateTime(data2.Key) <= EndDate
                            select new { Location = data.Combined_Key, Date = data2.Key, Count = data2.Value, Change = "" };

                foreach (var item in Query)
                {
                    var PrevDayCount = from data in AllCovidData
                                where data.Combined_Key == item.Location
                                from data2 in data.DailyData
                                where Convert.ToDateTime(data2.Key) == Convert.ToDateTime(item.Date).AddDays(-1)
                                select data2;

                    int CurrItemChange = Convert.ToInt32(item.Count) - Convert.ToInt32(PrevDayCount.First().Value);
                    DBreakdownData.Add(new DailyBreakdownData()
                    {
                        Location = item.Location,Date = item.Date,
                        TotalCases = item.Count,NewCases = CurrItemChange.ToString(),
                    });
                }

                var DistinctLocations = DBreakdownData.GroupBy(l => l.Location)
                                        .Select(i => new DailyBreakdownData
                                        {
                                            Location = i.First().Location,
                                            TotalCases = i.First().TotalCases,
                                            NewCases = i.Sum(c => Convert.ToInt32(c.NewCases)).ToString(),
                                        });

                foreach(DailyBreakdownData item in DistinctLocations)
                {
                    GrRepResponseItems.Add(new GrowthReportResponseItems() {
                        Location = item.Location, Number_Cases_At_Start = item.TotalCases,Number_Of_New_Cases = item.NewCases,
                        GrowthPercent = String.Format("{0:N2}%", ((Convert.ToDouble(item.NewCases)) / (Convert.ToDouble(item.TotalCases)) * 100)),
                    });
                }

                if (GrRepResponseItems.Count > 0)
                {
                    return JObject.FromObject(new GrowthReportResponse
                    {
                        Status = "SUCCESS",Items = GrRepResponseItems,
                    }).ToObject<GrowthReportResponse>();
                }
                else
                {
                    return JObject.FromObject(new GrowthReportResponse
                    {
                        ErrorMsg = "Please enter a valid County/City or State",Status = "FAIL"
                    }).ToObject<GrowthReportResponse>();
                }
                
            }
            catch (Exception ex)
            {
                return JObject.FromObject(new GrowthReportResponse
                {
                    Status = "FAIL",ErrorMsg = ex.Message,
                }).ToObject<GrowthReportResponse>();
            }
        }
    }
}
