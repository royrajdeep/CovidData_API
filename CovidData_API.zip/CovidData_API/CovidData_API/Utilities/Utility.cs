﻿using CovidData_API.InternalItems.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic.FileIO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;

namespace CovidData_API.Utilities
{
    /// <summary>
    /// This is a Utility class for common functions
    /// </summary>
    public static class Utility
    {
        /// <summary>
        /// Common utility method to read all csv data and return a List object
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static List<CovidData> GetCSV(string url)
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
            StreamReader sr = new StreamReader(resp.GetResponseStream());
            TextFieldParser TParser = new TextFieldParser(sr);
            List<CovidData> AllCovidData = new List<CovidData>();

            TParser.Delimiters = new string[] { "," };
            int count = 0;
            string[] Headers = new string[1];

            while (true)
            {
                string[] parts = TParser.ReadFields();
                if (parts == null)
                {
                    break;
                }
                else
                {
                    if (count == 0)
                    {
                        Headers = parts;
                    }

                    CovidData CovData = new CovidData();
                    CovData.UID = parts[0];
                    CovData.iso2 = parts[1];
                    CovData.iso3 = parts[2];
                    CovData.code3 = parts[3];
                    CovData.FIPS = parts[4];
                    CovData.Admin2 = parts[5];
                    CovData.Province_State = parts[6];
                    CovData.Country_Region = parts[7];
                    CovData.Lat = parts[8];
                    CovData.Long = parts[9];
                    CovData.Combined_Key = parts[10];
                    CovData.DailyData = new List<KeyValuePair<string, string>>();

                    for (int i = 11; i < parts.Length; i++)
                    {
                        CovData.DailyData.Add(new KeyValuePair<string, string>(Headers[i], parts[i]));
                    }
                    AllCovidData.Add(CovData);
                }
                count++;
            }
            sr.Dispose();

            return AllCovidData;
        }

        /// <summary>
        /// GetKeyFromSettings pulls the value of a key from the <c>Config</c> 
        /// </summary>
        /// <param name="Config">Configuration object</param>
        /// <param name="keyName">The name of the key to read from appSettings.json.</param>
        /// <returns>The value of keyName.</returns>
        public static string GetKeyFromSettings(IConfiguration Config, string keyName)
        {
            string keyValue = Config.GetValue<string>($"AppConfiguration:{keyName}");
            if (string.IsNullOrEmpty(keyValue))
            {
                keyValue = string.Empty;
            }
            return keyValue;
        }

        /// <summary>
        /// Function to retrieve County,State info from a thirdparty API
        /// </summary>
        /// <param name="City"></param>
        /// <param name="State"></param>
        /// <returns></returns>
        public static string GetCountyInfo(IConfiguration Config,string City,string State)
        {
            string County = City;
            string endpoint = GetKeyFromSettings(Config,"GeoAPI");
            HttpClient clientGIACT_ID = new HttpClient();
            clientGIACT_ID.BaseAddress = new Uri(endpoint);
            HttpResponseMessage responseGIACT_ID = new HttpResponseMessage();
            try
            {
                responseGIACT_ID = clientGIACT_ID.GetAsync("/6.2/geocode.json?city=" + City + "&State=" + State).GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                return County;
            }

            if (responseGIACT_ID.IsSuccessStatusCode && responseGIACT_ID.Content != null)
            {
                string response = responseGIACT_ID.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                JToken giactCheckObj = JToken.Parse(response);

                Rootobject root = new JObject(giactCheckObj.Children()).ToObject<Rootobject>();
                if (root.Response.View.Length > 0)
                    County = root.Response.View[0].Result[0].Location.Address.AdditionalData[2].value;
            }
            return County;
        }
    }


    public class Rootobject
    {
        public Response Response { get; set; }
    }

    public class Response
    {
        public Metainfo MetaInfo { get; set; }
        public View[] View { get; set; }
    }

    public class Metainfo
    {
        public DateTime Timestamp { get; set; }
    }

    public class View
    {
        public string _type { get; set; }
        public int ViewId { get; set; }
        public Result[] Result { get; set; }
    }

    public class Result
    {
        public float Relevance { get; set; }
        public string MatchLevel { get; set; }
        public Matchquality MatchQuality { get; set; }
        public Location Location { get; set; }
    }

    public class Matchquality
    {
        public float State { get; set; }
        public float City { get; set; }
    }

    public class Location
    {
        public string LocationId { get; set; }
        public string LocationType { get; set; }
        public Displayposition DisplayPosition { get; set; }
        public Navigationposition[] NavigationPosition { get; set; }
        public Mapview MapView { get; set; }
        public Address Address { get; set; }
    }

    public class Displayposition
    {
        public float Latitude { get; set; }
        public float Longitude { get; set; }
    }

    public class Mapview
    {
        public Topleft TopLeft { get; set; }
        public Bottomright BottomRight { get; set; }
    }

    public class Topleft
    {
        public float Latitude { get; set; }
        public float Longitude { get; set; }
    }

    public class Bottomright
    {
        public float Latitude { get; set; }
        public float Longitude { get; set; }
    }

    public class Address
    {
        public string Label { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string County { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        public Additionaldata[] AdditionalData { get; set; }
    }

    public class Additionaldata
    {
        public string value { get; set; }
        public string key { get; set; }
    }

    public class Navigationposition
    {
        public float Latitude { get; set; }
        public float Longitude { get; set; }
    }

}

