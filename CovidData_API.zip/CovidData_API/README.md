# DEMO_API
[![forthebadge](https://forthebadge.com/images/badges/60-percent-of-the-time-works-every-time.svg)](https://forthebadge.com)
[![forthebadge](https://forthebadge.com/images/badges/made-with-c-sharp.svg)](https://forthebadge.com)

Rebuilt the original POC used for the PING OAUTH ($/CossTools/Demo/Code/PING_OAUTH_POC) using [ASP.NET Core 3.1.1](https://dotnet.microsoft.com/apps/aspnet/apis).  

Logging is handled by [NLog](https://nlog-project.org/).

Web API help pages are handled by [Swagger](https://swagger.io/)/[OpenAPI](https://www.openapis.org/) using [Swashbuckle.AspNetCore](https://github.com/domaindrivendev/Swashbuckle.AspNetCore).

**A good starting point for PS developers to use when creating their project specific integrations.**

# Table of Contents
- [Components](#components)
- [How to Deploy on IIS](#how-to-deploy-to-iis)
- [How to View Swagger API Guide](#how-to-view-swagger-api-guide)
- [DEMO_API -> Carrier Specific](#demo_api---carrier-specific)
- [Helpful Links](#helpful-links)

# Components
### DEMO_API.csproj
- **ActionFilters** - `IActionFilter` that validates the ModelState of an incoming request.
- **Contracts** - Interfaces for API that defines the methods available.
- **Controllers** - Class that handles the different HTTP methods for the API.
- **CustomLoggingMiddleware** - Class that handles custom logging functionality.
- **Extensions** - Class to globally handle exceptions.
- **InernalItems** - Controller and Models that should be static across carrier implementations.
- **MockData** - JSON document that contains mock customer data.
- **Models** - Classes defining Data Transfer Objects used by the API.
- **Repositories** - Main class that handles the business logic of the API.
### LoggerService.csproj
- **LoggerManager** - Seperate, centralized logging manager.

# How to Deploy to IIS
1. Install [.NET Core 3.1.1 Hosting Bundle](https://dotnet.microsoft.com/download/dotnet-core/thank-you/runtime-aspnetcore-3.1.1-windows-hosting-bundle-installer)
2. In VS Code create a Publish Profile for IIS
   1. Select IIS, FTP, etc.
   2. Select Publish method: Web Deploy
   3. Enter 'localhost' for Server.
   4. Enter 'Default Web Site/DEMO_API' for Site name.
   5. Enter 'localhost/DEMO_API' for Destination URL.
3. Save and Publish
4. Optional:
   1. Create a new Application Pool in IIS called .NET Core
   ![](../../images/NewAppPool.png)
   2. Assign your service to the new .NET Application Pool
   ![](../../images/SelectAppPool.png)

You can find more helpful details [here](https://weblog.west-wind.com/posts/2016/Jun/06/Publishing-and-Running-ASPNET-Core-Applications-with-IIS)

# How to View Swagger API Guide
1. Navigate to http://localhost/demo_api/
![](../../images/swagger_example.gif)

# DEMO_API -> Carrier Specific
The following define how to take a copy of the DEMO_API and change it to work for your Carrier Specific integration.

1. Download a copy of this repo to your local machine.
   1. If you have a Carrier GitHub repo already setup, make sure you copy the **iGO-Demo/Code** files to your **CARRIER-NAME/Code** folder.
1. Replace all references of 'DEMO'.
   1. Copy the files located [here](https://github.com/ipipeline/iGO-Demo/tree/master/CustomUtilities) to your **CARRIER-NAME/Code** folder.
   1. Double-click the **run_ps.cmd** and follow the prompts. This will rename all files/folders and contents that contain 'DEMO' to the new name entered.  For example 'DEMO_API.csproj' to 'CARRIER-NAME_API.csproj'
      1. If you get an error stating "Running scripts is disabled on this system.", open a new PowerShell window as administrator and run: Set-ExecutionPolicy Unrestricted
   ![](../../images/renamer.gif)
1. Open solution and confirm no errors are thrown.
1. Modify the appsettings.json.
   1. Add/change the key/values in the **AppConfiguration** section to include your specific endpoints, un/pw, etc.
   ![](../../images/AppConfig.png)
   1. Change the values in the **ApiInformation** section to be specific for your integration.  For example who the contact person is, etc.
   ![](../../images/ApiInformation.png)
1. Modify the Controllers to your needs.
1. Modify the Repositories and Contracts for your needs.


# Helpful Links
[Intro to ASP.NET Core](https://docs.microsoft.com/en-us/aspnet/core/?view=aspnetcore-3.1)

[RESTful API Best Practices and Common Pitfalls](https://medium.com/@schneidenbach/restful-api-best-practices-and-common-pitfalls-7a83ba3763b5)

[ASP.NET Core Web API Best Practices](https://code-maze.com/aspnetcore-webapi-best-practices/)

[Top REST API Best Practices](https://code-maze.com/top-rest-api-best-practices/)

[NLog Configuration Options](https://nlog-project.org/config/)

[Getting Started with Swashbuckle](https://docs.microsoft.com/en-us/aspnet/core/tutorials/getting-started-with-swashbuckle?view=aspnetcore-3.1&tabs=visual-studio)
