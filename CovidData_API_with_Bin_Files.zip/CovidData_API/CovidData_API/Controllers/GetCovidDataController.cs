﻿using CovidData_API.Contracts;
using CovidData_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace CovidData_API.Controllers
{
    /// <summary>
    /// </summary>
    [Produces("application/json")]
    [Route("api/GetCovidData")]
    public class GetCovidDataController : Controller
    {

        private readonly IGetCovidDataRepository _getCovidDataRepository;
        /// <summary>
        /// Constructor that creates an instance of the API interface.
        /// </summary>
        public GetCovidDataController(IGetCovidDataRepository GetCovidDataRepository)
        {
            _getCovidDataRepository = GetCovidDataRepository;
        }

        /// <summary>
        /// Gets a Daily report on the number of cases, Max case with Date, Min Cases with Date and Avg. number of cases during the time period
        /// Input Params - County, State, DateRange. Example - Baldwin, Alabama, 5/1/2020-5/2/2020
        /// Note: A City name may be provided for the param "County". Application will lookup the appropriate county name.
        /// </summary>
        /// <param name="County/City"></param>
        /// <param name="State"></param>
        /// <param name="DateRange"></param>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(IVResponse), 200)]
        public IActionResult GetCovidData(string County, string State, string DateRange)
        {
            return Ok(_getCovidDataRepository.GetCovidData(County, State, DateRange));
        }
    }
}