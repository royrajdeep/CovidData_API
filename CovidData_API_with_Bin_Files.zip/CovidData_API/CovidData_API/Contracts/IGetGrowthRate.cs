﻿using CovidData_API.Models;
using System.Collections.Generic;

namespace CovidData_API.Contracts
{
    /// <summary>
    /// Get Covid Daily GetGrowthRate
    /// </summary>
    /// <remarks>
    /// Your project will have a class that inherits from this interface in the Repositories directory, so you need to make sure both are in sync.
    /// </remarks>
    public interface IGetGrowthRateRepository
    {
        /// <summary>
        /// Gets Covid Daily GrowthRate
        /// </summary>
        /// <returns>
        /// All Covid Data
        /// </returns>
        GrowthReportResponse GetGrowthRate(string County = "", string State = "", string DateRange = "");
    }
}
