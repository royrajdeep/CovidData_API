﻿using CovidData_API.Models;

namespace CovidData_API.Contracts
{
    /// <summary>
    /// Get Covid Data
    /// </summary>
    /// <remarks>
    /// Your project will have a class that inherits from this interface in the Repositories directory, so you need to make sure both are in sync.
    /// </remarks>
    public interface IGetCovidDataRepository
    {
        /// <summary>
        /// Gets Covid Data 
        /// </summary>
        /// <returns>
        /// All Covid Data
        /// </returns>
        IVResponse GetCovidData(string County = "", string State = "", string DateRange = "");
    }
}
